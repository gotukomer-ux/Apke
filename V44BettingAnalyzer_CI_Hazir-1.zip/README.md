# V4.4 Betting Analyzer — Android MVP

Bu proje V4.4 futbol bahis analiz motoru için başlangıç Android uygulamasıdır.

## Şu an
- Kotlin + Jetpack Compose
- Türkçe arayüz
- Maç girişi
- Analiz ekranı iskeleti
- Market kategorileri
- İnternet izni

## Gerçek canlı analiz için sonraki katman
1. API-Football bağlantısı
2. Fikstür / takım / istatistik / sakatlık / oran verileri
3. V4.4 olasılık ve EV motoru
4. AI açıklama katmanı
5. Güvenli backend proxy (API anahtarları APK'ya gömülmez)
6. Kupon fotoğrafı OCR

## APK
Android Studio ile açıp Gradle senkronizasyonundan sonra:
Build > Build APK(s)

Not: Canlı API anahtarı bu projeye bilerek gömülmemiştir.


## APK'yı otomatik üretme (GitHub Actions)

Bu projeye `.github/workflows/build-apk.yml` eklendi. Projeyi bir GitHub reposuna yüklediğinde GitHub, Android build ortamında APK'yı otomatik derleyip `V44-Betting-Analyzer-debug` adlı artifact olarak verir.

Kısa yol:
1. GitHub'da yeni bir repository oluştur.
2. ZIP'i bilgisayarda aç ve içindeki dosyaları repository'ye yükle.
3. `Actions` sekmesine gir.
4. `Build Android APK` workflow'unu çalıştır veya `main` dalına push yap.
5. Workflow tamamlanınca run sayfasından `Artifacts` bölümündeki APK'yı indir.

Bu ilk APK debug sürümüdür. Canlı futbol API'si henüz bağlanmamıştır.
