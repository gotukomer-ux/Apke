package com.v44betting.analyzer

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

data class Pick(
    val market: String,
    val selection: String,
    val probability: Int,
    val odds: Double,
    val ev: Double,
    val risk: String
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { V44App() }
    }
}

@Composable
fun V44App() {
    var home by remember { mutableStateOf("") }
    var away by remember { mutableStateOf("") }
    var odds by remember { mutableStateOf("") }
    var analyzed by remember { mutableStateOf(false) }

    MaterialTheme {
        Scaffold(
            topBar = { TopAppBar(title = { Text("⚽ V4.4 Betting Analyzer") }) }
        ) { pad ->
            LazyColumn(
                modifier = Modifier.padding(pad).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item { Text("FULL MARKET SCANNER", style = MaterialTheme.typography.headlineSmall) }
                item { Text("Maç bilgilerini gir. Canlı API bağlantısı sonraki entegrasyon katmanında kullanılacak.") }

                item {
                    OutlinedTextField(home, { home = it }, label = { Text("Ev sahibi") },
                        modifier = Modifier.fillMaxWidth())
                }
                item {
                    OutlinedTextField(away, { away = it }, label = { Text("Deplasman") },
                        modifier = Modifier.fillMaxWidth())
                }
                item {
                    OutlinedTextField(odds, { odds = it }, label = { Text("MS oranı (opsiyonel)") },
                        modifier = Modifier.fillMaxWidth())
                }
                item {
                    Button(
                        onClick = { analyzed = true },
                        enabled = home.isNotBlank() && away.isNotBlank(),
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("🔎 V4.4 ANALİZİ BAŞLAT") }
                }

                if (analyzed) {
                    item { AnalysisCard(home, away, odds) }
                }
            }
        }
    }
}

@Composable
fun AnalysisCard(home: String, away: String, odds: String) {
    val picks = listOf(
        Pick("MS", "$home kazanır", 0, 0.0, 0.0, "Veri bekleniyor"),
        Pick("ÇŞ / DNB", "Alternatif market", 0, 0.0, 0.0, "Veri bekleniyor"),
        Pick("Alt/Üst 2.5", "Market taranacak", 0, 0.0, 0.0, "Veri bekleniyor"),
        Pick("KG", "Market taranacak", 0, 0.0, 0.0, "Veri bekleniyor"),
        Pick("İlk Yarı", "Market taranacak", 0, 0.0, 0.0, "Veri bekleniyor")
    )

    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("$home  —  $away", style = MaterialTheme.typography.titleLarge)
            Text("V4.4 tarama sonucu", style = MaterialTheme.typography.titleMedium)
            Text("⚠️ Bu ilk MVP'dir. Canlı veri/API bağlanmadan gerçek olasılık veya EV üretilmez.")
            if (odds.isNotBlank()) Text("Girilen MS oranı: $odds")

            picks.forEach {
                HorizontalDivider()
                Text("${it.market}: ${it.selection}")
                Text("Olasılık: ${if (it.probability == 0) "—" else "%${it.probability}"}  •  EV: ${if (it.ev == 0.0) "—" else "%.1f%%".format(it.ev)}  •  Risk: ${it.risk}")
            }
        }
    }
}
